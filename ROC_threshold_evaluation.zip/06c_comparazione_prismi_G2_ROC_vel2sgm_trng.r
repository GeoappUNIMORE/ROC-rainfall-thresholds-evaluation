
require(flux)
pr <- c(paste("pr0",seq(1,9),sep=''),paste("pr",seq(10,20),sep=''))
name <- c('01_day','03_day','05_day','07g','10g','15g','20g','25g','30g','35g','40g','45g','50g','60g','70g','80g','90g','100g','110g','120g')
variabili <- c('roc_space_001g','roc_space_003g','roc_space_005g','roc_space_007g','roc_space_010g','roc_space_015g','roc_space_020g','roc_space_025g',
               'roc_space_030g','roc_space_035g','roc_space_040g','roc_space_045g','roc_space_050g','roc_space_060g',
               'roc_space_070g','roc_space_080g','roc_space_090g','roc_space_100g','roc_space_110g','roc_space_120g')
AUC_MAXdist <- as.data.frame(matrix(NA, ncol=length(pr)+1,nrow=length(name))); colnames(AUC_MAXdist) <- c("t_cumulate",pr); AUC_MAXdist$t_cumulate <- name

#  m <- 1
setwd("C:/Dottorato/Casi_studio/Collagna/Erre/06c_ROC_threschold_comparate_Training/vel/")
for (m in (1:20)) { #contatore prismi
  for (i in (1:20)) { #contatore cumulate precipitazione
 
  load(paste0("C:/Dottorato/Casi_studio/Collagna/Erre/06b_soglie_vel_prec_Training/06b_soglie_vel_2sg_trng/06b_soglie_trng_",pr[m],"_vel2sgm-prec_",name[i],sep=''))
 assign(variabili[i],roc_space)
  }


if (length(ls()) > 29) rm(roc_space,false,true,tp_index,tp_rate,fp_index,fp_rate)

# per richiamare i risultati delle curve di roc *1<- 10g *2<- 15g *3<- 1day *4<-3day *5<-5g *6<-7g
roc_spaces <-ls(); roc_spaces <- roc_spaces[-c(1:5,length(roc_spaces))]


AUC_MAXdist_vel2sgm <- as.data.frame(matrix(NA,nrow=length(roc_spaces), ncol=6)); colnames(AUC_MAXdist_vel2sgm) <- c("Prec","AUC","MAXdist","Combination","fp_rate","tp_rate")
AUC_MAXdist_vel2sgm$Prec <- c('01-day','03-day','05-day','07-day','10-day','15-day','20-day','25-day','30-day','35-day','40-day','45-day','50-day','60-day','70-day','80-day','90-day','100-day','110-day','120-day')


index_legend <- seq(1,length(roc_spaces),1)

dist_MAX_indx <- matrix(NA, nrow=length(roc_spaces), ncol=1)
for (i in 1:length(roc_spaces)) {
  dist_MAX_indx[i] <- which.max(get(roc_spaces[i])[,5])
}
##prec da 1g a 35gg
par(mfrow=c(2,2),mar= c(2,5,2,1)+.1,pty="s")
plot(get(roc_spaces[1])[,3],get(roc_spaces[1])[,2],type='l',lty=1, xlim=c(0,1),ylim=c(0,1),xlab="FP-rate",ylab="TP-rate",asp=1,main="ROC space")
points(get(roc_spaces[1])[dist_MAX_indx[1],3],get(roc_spaces[1])[dist_MAX_indx[1],2],pch=16,cex=0.7)
for (i in 2:(11)) {
  par(new=T)
  plot(get(roc_spaces[i])[,3],get(roc_spaces[i])[,2],type='l',lty=i, xlim=c(0,1),ylim=c(0,1),xaxt='n',yaxt='n',,xlab="",ylab="",asp=1)
  points(get(roc_spaces[i])[dist_MAX_indx[i],3],get(roc_spaces[i])[dist_MAX_indx[i],2],pch=16,cex=0.7)
  
}
abline(a=0,b=1,lty=1,col='grey')
legend('bottomright',legend=AUC_MAXdist_vel2sgm$Prec[1:11],lty=index_legend[1:11],bty='n',cex=0.6)

##prec da 40gg a 120gg
plot(get(roc_spaces[12])[,3],get(roc_spaces[12])[,2],type='l',lty=1, xlim=c(0,1),ylim=c(0,1),xlab="FP-rate",ylab="TP-rate",asp=1,main="ROC space")
points(get(roc_spaces[12])[dist_MAX_indx[12],3],get(roc_spaces[12])[dist_MAX_indx[12],2],pch=16,cex=0.7)
for (i in 1:(9)) {
  par(new=T)
  plot(get(roc_spaces[i+11])[,3],get(roc_spaces[i+11])[,2],type='l',lty=i, xlim=c(0,1),ylim=c(0,1),xaxt='n',yaxt='n',,xlab="",ylab="",asp=1)
  points(get(roc_spaces[i+11])[dist_MAX_indx[i+11],3],get(roc_spaces[i+11])[dist_MAX_indx[i+11],2],pch=16,cex=0.7)
  
}
abline(a=0,b=1,lty=1,col='grey')
legend('bottomright',legend=AUC_MAXdist_vel2sgm$Prec[12:20],lty=index_legend[1:7],bty='n',cex=0.6)



for (i in 1:length(roc_spaces)) {
  AUC_MAXdist_vel2sgm$AUC[i] <- auc(get(roc_spaces[i])[,3],get(roc_spaces[i])[,2])
}



### assegno a AUC_MAXdist_velXXX$MAXdist il valore della distanza massima
index <- seq(1,20,1)
for (i in 1:20) {
  AUC_MAXdist_vel2sgm$MAXdist[index[i]] <- get(roc_spaces[i])[dist_MAX_indx[i],5]
  AUC_MAXdist_vel2sgm$Combination[index[i]] <- get(roc_spaces[i])[dist_MAX_indx[i],1]
  AUC_MAXdist_vel2sgm$fp_rate[index[i]] <- get(roc_spaces[i])[dist_MAX_indx[i],3]
  AUC_MAXdist_vel2sgm$tp_rate[index[i]] <- get(roc_spaces[i])[dist_MAX_indx[i],2]
}

plot(1:11,AUC_MAXdist_vel2sgm$AUC[1:11],type='h',ylab="Area Under Curve",xlab="",xaxt='n',main='Area Under Curve',ylim=c(0,1)); axis(1,at=1:11,labels=AUC_MAXdist_vel2sgm$Prec[1:11])
title(sub="Precipitation moving window",line=3)
title(outer=T,main=paste("2*SIGMA - ",pr[m],sep=""),line=-2)
abline(h=0.7,col='grey')

plot(12:20,AUC_MAXdist_vel2sgm$AUC[12:20],type='h',ylab="Area Under Curve",xlab="",xaxt='n',main='Area Under Curve',ylim=c(0,1)); axis(1,at=12:20,labels=AUC_MAXdist_vel2sgm$Prec[12:20])
title(sub="Precipitation moving window",line=3)
abline(h=0.7,col='grey')


save(AUC_MAXdist_vel2sgm,file=paste("06c_AUC-MAXdist_vel2sgm_trng_",pr[m],sep=''))
rm(AUC_MAXdist_vel2sgm,dist_MAX_indx,index,index_legend,roc_spaces)
}
# par(mfrow=c(1,1),mar= c(4,3,2,2)+.1,pty="s")
# plot(1:20,AUC_MAXdist_vel2sgm$MAXdist,type="p",pch=16,ylab="Distance",xlab="Rain Moving Window (day)",xaxt='n',ylim=c(0,sqrt(2)/2),main=paste("Vel. 2Sigma ",pr[m]," - Distance from Random",sep=""));axis(1,at=1:20,labels=c('1','3','5','7',seq(10,50,5),seq(60,120,10)))
# abline(v=1:20,col="grey",lty=3); abline(h=seq(0,1,0.05),col="grey",lty=3)
# 
